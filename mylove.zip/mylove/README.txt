Put these files in THIS same folder, next to index.html:
photo1.jpg photo2.jpg photo3.jpg photo4.jpg photo5.jpg photo6.jpg
song.mp3
Then upload the whole folder contents to your GitHub repository.
